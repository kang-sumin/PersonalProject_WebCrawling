


class Place:
    def __init__(self,number,n_cashier=[]):
        self.n_cashier=n_cashier
        self.number=number

    def n_of_cashier(self,number):
        for i in range(number):
            self.n_cashier.append({i+1:0})
        print("Number of Cashier")
        print(self.n_cashier)
        print("*******************************************")    
    def cus_input(self):
        for time in customer_time:
            print("Cashier after Each Customer Arrives")
            self.n_cashier[0][1]+=time
            print(self.n_cashier)
            #self.n_cashier.sort()
        print(self.n_cashier[0])
    def maxtime(self):
       print("Time Required for Checking out : ",max(self.n_cashier))
        


if __name__=="__main__":
    customer_time=[4,3,2,8,7,7,5]
    number_of_cashier=[]
    n=int(input("Cashier의 수를 입력 하세요 : "))
    a=Place(n)
    a.n_of_cashier(n)
    a.cus_input()
    #a.maxtime()


