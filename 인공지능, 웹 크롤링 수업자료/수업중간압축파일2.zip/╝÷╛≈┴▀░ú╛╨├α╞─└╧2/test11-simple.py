

class Place:

    def n_of_cashier(self):
        print("Number of Cashier")
        print(number_of_cashier)
        print("*******************************************")    
    def cus_input(self):
        for time in customer_time:
            print("Cashier after Each Customer Arrives")
            number_of_cashier.sort()
            number_of_cashier[0]+=time
            print(number_of_cashier)
    def maxtime(self):
        print("Time Required for Checking out : ",max(number_of_cashier))
        


if __name__=="__main__":
    customer_time=[4,3,2,8,7,7,5]
    number_of_cashier=[]
    n=int(input("Cashier의 수를 입력 하세요 : "))
    for i in range(n):
        number_of_cashier.append(0)
        
    a=Place()
    a.n_of_cashier()
    a.cus_input()
    a.maxtime()

'''
class Place:
    def __init__(self,number,n_cashier=[]):
        self.n_cashier=n_cashier
        self.number=number

    def n_of_cashier(self,number):
        for i in range(number):
            self.n_cashier.append(0)
        print("Number of Cashier")
        print(self.n_cashier)
        print("*******************************************")    
    def cus_input(self):
        for time in customer_time:
            print("Cashier after Each Customer Arrives")
            self.n_cashier[0]+=time
            print(self.n_cashier)
            self.n_cashier.sort()
    def maxtime(self):
        print("Time Required for Checking out : ",max(self.n_cashier))
        


if __name__=="__main__":
    customer_time=[4,3,2,8,7,7,5]
    number_of_cashier=[]
    n=int(input("Cashier의 수를 입력 하세요 : "))
    a=Place(n)
    a.n_of_cashier(n)
    a.cus_input()
    a.maxtime()
'''
