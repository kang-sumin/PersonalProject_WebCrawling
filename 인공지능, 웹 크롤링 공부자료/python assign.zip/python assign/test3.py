import os

print("\n\n************** 2번 **************")
number=int(input("숫자를 입력하세요 : "))

if number%2==0:
    print(number,"짝수입니다.")
else:
    print(number, "홀수입니다.")


print("\n\n************* 6번 ***************")

a=[1,3,5,4,2]
print("a = ",a)
a.sort()
print("a = ",a)
a.reverse()
print("a = ",a)

print("\n\n************* 11번 ***************")

a=[1,1,1,2,2,3,3,3,4,4,5]
print("a = ",a)
aSet=set(a)
print("aSet = ",aSet)
b=list(aSet)
print("b = ",b)


os.system("pause")
