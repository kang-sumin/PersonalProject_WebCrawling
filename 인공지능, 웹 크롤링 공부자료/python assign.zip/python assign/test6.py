import os
'''
print("\n\n**********소수 구하기**********")
n=int(input("숫자를 입력해 주세요 : "))
def is_prime(n):
    if n==1:
        return False
    for i in range(2,n):
        if(n%i==0):
            return False
    return True

print(n,"은 소수인가? : ",is_prime(n))


print("\n\n**********Random Password**********")
import random

def getPass():
    alphabet="abcdefghijklmnopqrstuvwxyz0123456789"
    password=""
    for i in range(6):
        index=random.randrange(len(alphabet))
        password=password+alphabet[index]
    return password

for i in range(3):
    print(getPass())


n=input("숫자들을 입력하세요 : ").split(",")
print(n)
n=list(map(int,n))
print(n)
ns=tuple(n)
print(ns)
result=0
def add_many(*args):
    global result
    for i in args:
        result=result+i
    return result

for i in n:
    add_many(i)
print(result)

print(add_many(ns))

'''
print("\n\n**********피보나치 수열**********")
def fib(n):
    flist=[1, 1]
    if n==1 or n==2:
        return
    for i in range(2,n):
        flist.append( flist[i-1] + flist[i-2] )
        if flist[i]>n:
            break

    return flist[0:i]

print(fib(100))

'''
#n=int(input("숫자를 입력해 주세요  : "))
def fib(s):
    flist=[]
    for i in range(0,s):
        if i<2:
            flist.append(1)
        else:
            flist.append(flist[i-1]+flist[i-2])
    return flist[s-1]


print(fib(100))

'''
print("\n\n**********원의 면적 및 둘레**********")
PI=3.14
r=int(input("반지름을 입력해 주세요 : "))

def area(r):
    global PI
    return PI*r*r

def rround(r):
    global PI
    return 2*PI*r

print("원의 면적 = ",area(r))
print("원의 둘레 = ",rround(r))

os.system("pause")
