import os

def add(a,b):
    return a+b

def subt(a,b):
    return a-b

def mult(a,b):
    return a*b

def divi(a,b):
    return a/b


print("계산기 프로그램 입니다.",end=" ")
while True:
    print("\n(1.덧셈  2.뺄셈  3.곱셈  4.나눗셈  5.종료)")
    s=int(input("1~5번 사이를 입력해 주세요 : "))
    if s==5:
        print("계산기 프로그램을 종료 합니다!")
        break
    n1,n2=map(int,input("두 정수 입력 : ").split(" "))
    if s==1:
        print("결과는",add(n1,n2),"입니다!")
    if s==2:
        print("결과는",subt(n1,n2),"입니다!")
    if s==3:
        print("결과는",mult(n1,n2),"입니다!")
    if s==4:
        print("결과는",divi(n1,n2),"입니다!")
    


os.system("pause")
