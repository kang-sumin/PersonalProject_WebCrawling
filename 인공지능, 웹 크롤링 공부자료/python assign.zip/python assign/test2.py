'''
import os

word=input("단어를 입력해 주세요 : ")
partision=set(word)

print(partision)

def star():
    print("\t| ","*"*count)


for i in partision:
    count=0
    print(i," : ", end="")
    for j in word:
        if i==j:
            count=count+1
    print(count,"회",end="")
    star()


os.system("pause")        

'''
import os

word=input("단어를 입력해 주세요 : ")
partision={x:x for x in (word)}

print(partision)

def star():
    print("\t| ","*"*count)


for i in partision:
    count=0
    for j in word:
        if i==j:
            count=count+1
    print(i," : ",count,"회",end="")
    star()


os.system("pause")

