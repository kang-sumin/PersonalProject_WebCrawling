print("\n***cmd 창에서는 입출력실행이 visual하지 않음으로 IDLE창에서 실행해 주시기 바랍니다!!!***\n")
print("계좌활동시에는 1번을 읽어주시고, 리스트 활동시 2번을 읽어주세요!!!")

class BankAcct:
    def __init__(self, balance=0):
        self.balance=balance

    def deposit(self, balance):
        self.balance+=balance

    def withdraw(self, balance):
        if self.balance>balance:
            self.balance-=balance
        else:
            print("인출 불가 : 잔고가 부족함")
            exit()

print("1. 계좌를 생성후, 계좌 활동을 입력해 주세요(deposit, withdraw)")



class Queue:
    def __init__(self,queue=[]):
        self.queue=queue

    def isEmpty(self):
        if self.queue==[]:
            print("True")
        else:
            print("False")

    def addQueue(self,queue):
        self.queue.append(queue)

    def delQueue(self):
        del self.queue[0]
        #self.queue.remove()


print("2. 리스트를 생성후, 수행하고자 하는 것을 입력해 주세요(isEmpty, addQueue, delQueue)")

input()

