import os

'''
table=[]
count=0

for i in range(10):
    print("*****",i+1,"번째 person*****")
    age=input("나이를 입력해 주세요! : ")
    income=input("소득이 어느정도 인지 입력해 주세요! : ")
    student=input("학생입니까? : ")
    credit_rating=input("신용을 입력해 주세요! : ")
    buy_computer=input("컴퓨터를 샀는가? : ")
    person=[age,income,student,credit_rating,buy_computer]
    table+=[person]
'''
count=0
table=[[20,'high','yes','fiar','no'],[30,'low','no','fiar','yes'],[20,'high','yes','high','yes']]
#print(table)

for i in range(len(table)):
    print(table[i])


for i in range(len(table)):
    if(table[i][1]=="high"and table[i][4]=="yes"):
        print(i+1,"번째사람의 소득이 high 하면서 컴퓨터를 산 사람입니다!")
        count+=1
print("\n소득이 높으면서 컴퓨터를 산 사람은",count,"명 입니다.")


os.system("pause")
