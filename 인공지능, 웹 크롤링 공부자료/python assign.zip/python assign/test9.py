'''
class FourCal:
    def __init__(self,first,second):
        self.first=first
        self.second=second
    def add(self):
        result=self.first+self.second
        return result
    def mul(self):
        result=self.first*self.second
        return result
    def sub(self):
        result=self.first-self.second
        return result
    def div(self):
        result=self.first/self.second
        return result

class MoreFourCal(FourCal):
    def pow(self):
        result=self.first**self.second
        return result
    def froot(self):
        result=self.first**0.5
        return result
    def sroot(self):
        result=self.second**0.5
        return result
    def avg(self):
        result=(self.first+self.second)/2
        return result


a=MoreFourCal(4,2)
b=FourCal(3,8)
print(a.add())
print(a.mul())
print(a.sub())
print(a.div())
print(a.pow())
print(a.froot())
print(a.sroot())
print(a.avg())
print(b.add())
print(b.mul())
print(b.sub())
print(b.div())
'''
class BankAccount:
    def __init__(self,number=1,balance=10000):
        self.number=number
        self.balance=balance
    def withdraw(self,amount):
        self.balance=self.balance-amount
        return self.balance
    def deposit(self,amount):
        self.balance=self.balance+amount
        return self.balance

class SavingAccount(BankAccount):
    def __init__(self,balance=10000,interest_rate=0):
        self.balance=balance
        self.interest_rate=interest_rate
    def set_interest_rate(self,interest_rate):
        self.interest_rate=interest_rate
    def get_interest_rate(self):
        return self.interest_rate
    def add_interest(self):
        self.balance+=self.balance*self.interest_rate

class WithdrawAccount(BankAccount):
    def withdraw(self,amount):
        self.balance=self.balance-amount-5000
        return self.balance

a=BankAccount()
b=SavingAccount()
c=WithdrawAccount()



