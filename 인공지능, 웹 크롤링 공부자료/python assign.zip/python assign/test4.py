import os
'''
money=int(input("가지고 있는 돈을 입력하세요! : "))
card=input("카드를 가지고 있으신가요?(y/n) : ")

while True:
    if card=='y' or card=='n':
        if money>=3000 or card=='y':
            print("^--^ 택시를 타고 가시는 것이 좋습니다!")
            break
        else:
            print("ㅠ^ㅠ 걸어가야 할 거 같네요...")
            break
    else:
        print("카드 유뮤를 (y/n)중에서 입력해 주세요!")
        card=input("카드를 가지고 있으신가요?(y/n) : ")

while True:
    m=int(input("\n\n구입 금액을 입력하세요 : "))

    if m>=100000:
        print("*십만원 이상 구매하셔서 5%할인 받으실수 있으십니다!!!*")
        h=m*0.05
        print("=>할인금액은",h,"원 입니다!")
        print("=>지불하실 금액은 총",m-h,"원 입니다!")
    else:
        w=100000-m
        print("*",w,"원 더 구입하시면 5% 할인을 받으실수 있습니다!*")
'''
word=input("문자열을 입력하세요 : ")

if len(word)%2==0:
    print("글자수가 짝수임으로 중간 글자를 찾을 수 없습니다...")
else:
    x=len(word)//2+1
    print("중간 글자 : ",word[x])


os.system("pause")
