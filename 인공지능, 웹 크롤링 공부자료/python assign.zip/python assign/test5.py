import os

mark=[90,25,67,45,80]
number=0
for i in mark:
    number=number+1
    if i>60:
        print("%d번 학생은 합격입니다. "%number)
    else:
        print("%d번 학생은 불합격입니다. "%number)

os.system("pause")
